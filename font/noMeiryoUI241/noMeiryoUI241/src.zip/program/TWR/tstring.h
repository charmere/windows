/*
noMeiryoUI (C) 2005,2012,2013 Tatsuhiko Shoji
The sources for noMeiryoUI are distributed under the MIT open source license
*/
#ifndef TSTRING
#define TSTRING

#include <tchar.h>
#include <string>

typedef std::basic_string<TCHAR> tstring;

#endif
